<?php
DEFINE ('DB_USER', 'your_linkblue_id');
DEFINE ('DB_PASSWORD','your_password');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'linkblue_ict301');

// Make the connection.
$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('could not connect to MySQL: ' . mysqli_error());
?>
