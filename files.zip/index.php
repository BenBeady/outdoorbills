<?php
// Call the DB connection function, mysqli_connect.php
require_once('includes/mysqli_connect.php');
// Create a query to retrieve all records
$query = "SELECT * FROM bookmark";
$result = @mysqli_query($dbc, $query);
$num = mysqli_num_rows($result);

if($num > 0) { // if there is any record, display all records
    echo "<p>There are $num records</p>";
    // print out all records
    while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
        echo "<p>Title: $row[title] <br>";
        echo "Comment: $row[comment] <br>";
        echo "URL: <a href=$row[url] target=_blank>$row[url]</a></p>";
    }
} else { // if there is no record, print out the following message
    echo "<p>There is no record</p>";
}
mysqli_close($dbc); // close the DB connection
?>
